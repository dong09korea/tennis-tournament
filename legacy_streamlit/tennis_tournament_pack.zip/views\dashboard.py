import streamlit as st
import pandas as pd
from utils import logic
from views import bracket

def render(db):
    st.title("📊 대회 현황 (Public Dashboard)")
    
    col_nav1, col_nav2 = st.columns([1, 4])
    with col_nav1:
        if st.button("🏠 홈으로", use_container_width=True):
            st.query_params.clear()
            st.rerun()
    with col_nav2:
        if st.button("새로고침", use_container_width=True):
            st.rerun()

    # Smart Format with players helper
    def get_smart_name(t):
        name = t['name']
        p1 = t.get('player1', '')
        p2 = t.get('player2', '')
        if p1 or p2:
            if f"{p1}, {p2}" not in name:
                 return f"{name}\n({p1}, {p2})"
        return name

    # 1. Live Courts
    st.subheader("실시간 코트 현황")
    courts = db.get_courts()
    matches = db.get_matches()
    teams = db.get_teams()
    
    c_cols = st.columns(3)
    for i in range(6):
        court = courts[i]
        match = next((m for m in matches if m['id'] == court['match_id']), None)
        
        with c_cols[i%3]:
            st.markdown(f"<h3 style='text-align: center; margin-bottom: 5px;'>{court['id']}번 코트</h3>", unsafe_allow_html=True)
            if match:
                tA = next(t for t in teams if t['id'] == match['team_a_id'])
                tB = next(t for t in teams if t['id'] == match['team_b_id'])
                
                nA = get_smart_name(tA).replace("\n", " ") # Flatten
                nB = get_smart_name(tB).replace("\n", " ")
                
                group_label = f"{match['group_id']}조" if isinstance(match['group_id'], int) else match['group_id']
                
                # Check for Tie Break
                is_tie_break = match.get('is_tie_break', False)
                pts_map = ['0', '15', '30', '40', 'AD']
                
                if is_tie_break:
                    pa = match['point_a']
                    pb = match['point_b']
                    tb_html = "<span style='background:#FF5722; color:white; font-size:0.6em; padding:2px 4px; border-radius:4px; vertical-align:middle;'>TIE BREAK</span>"
                else:
                    pa = pts_map[match['point_a']]
                    pb = pts_map[match['point_b']]
                    tb_html = ""
                
                # Custom Card HTML
                html = f"""
<div style="background-color: #262730; border: 1px solid #444; border-radius: 8px; padding: 15px; text-align: center; margin-bottom: 20px;">
<div style="color: #888; font-size: 0.9em; margin-bottom: 4px;">{group_label} {match['round']}경기 {tb_html}</div>
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
<div style="flex: 1; text-align: center;">
<div style="font-weight: bold; font-size: 1.1em; color: #fff;">{nA}</div>
</div>
<div style="font-weight: 900; font-size: 1.5em; padding: 0 10px; color: #ddd;">vs</div>
<div style="flex: 1; text-align: center;">
<div style="font-weight: bold; font-size: 1.1em; color: #fff;">{nB}</div>
</div>
</div>
<div style="background: #0e1117; border-radius: 6px; padding: 8px;">
<div style="font-size: 0.8em; color: #aaa;">SET SCORE</div>
<div style="font-size: 2.2em; font-weight: 900; color: #4CAF50;">{match['score_a']} : {match['score_b']}</div>
<div style="margin-top: 5px; font-size: 1.2em; color: #FFC107;">
<span style='font-size:0.7em; color:#777;'>POINTS</span> {pa} - {pb}
</div>
</div>
</div>
"""
                st.markdown(html, unsafe_allow_html=True)

            else:
                 st.markdown("""
                 <div style="
                    background-color: #262730; 
                    border: 1px dotted #555; 
                    border-radius: 8px; 
                    padding: 30px; 
                    text-align: center; 
                    margin-bottom: 20px;
                    color: #666;
                 ">
                    대기 중
                 </div>
                 """, unsafe_allow_html=True)

    # Tabs for Standings and Bracket
    draw_active = db.knockout_draw.get('is_active', False)
    
    if draw_active:
        # Knockout Phase: Bracket First
        tab2, tab1 = st.tabs(["🧬 토너먼트 대진표 (Bracket)", "🏆 조별 순위 (Standings)"])
    else:
        # Prelim Phase: Standings First
        tab1, tab2 = st.tabs(["🏆 조별 순위 (Standings)", "🧬 토너먼트 대진표 (Bracket)"])
    
    with tab1:
        st.subheader("실시간 조별 순위")
        groups = db.get_groups()
        
        # Calculate stats roughly (or use logic.calculate_standings if efficient)
        team_stats = logic.calculate_standings(db)
        
        # Display Grid
        g_cols = st.columns(4)
        for i, group in enumerate(groups):
            with g_cols[i%4]:
                st.markdown(f"**{group['name']}**")
                data = []
                for tid in group['team_ids']:
                    s = team_stats[tid].copy()
                    
                    # Helper to format name for standings
                    t_obj = next((t for t in teams if t['id'] == tid), None)
                    if t_obj:
                         s['name'] = get_smart_name(t_obj).replace('\n', ' ') # Flatten for table
                         
                    data.append(s)
                
                df = pd.DataFrame(data)
                # Sort by Pts desc, then Games desc
                df = df.sort_values(by=['Pts', 'Games'], ascending=[False, False])
                
                # Translate columns
                df = df.rename(columns={'name': '팀이름', 'W': '승', 'L': '패', 'D': '무', 'Pts': '승점', 'Games': '득실'})
                
                st.dataframe(df[['팀이름', '승', '무', '패', '승점', '득실']], hide_index=True, use_container_width=True)

    with tab2:
        st.subheader("토너먼트 대진표")
        bracket.render(db)

import streamlit as st
import pandas as pd
from utils import logic
from views import bracket
from utils import auth

def render(db):
    if not auth.check_password('admin', '5132'):
        return
    if st.button("홈으로", use_container_width=True):
        st.query_params.clear()
        st.rerun()

    st.title("운영진 대시보드")
    
    # Check if tournament started
    teams = db.get_teams()
    
    # Helper for names
    def get_smart_name(t):
        name = t['name']
        p1 = t.get('player1', '')
        p2 = t.get('player2', '')
        if p1 or p2:
            if f"{p1}, {p2}" not in name:
                 return f"{name}\n({p1}, {p2})"
        return name
    
    if not teams:
        st.header("대회 설정")
        
        tab_manual, tab_excel = st.tabs(["직접 입력", "엑셀 업로드"])
        
        with tab_manual:
            with st.form("setup_form"):
                st.write("32개 팀 이름을 입력하세요 (기본값 제공)")
                cols = st.columns(4)
                team_names = []
                for i in range(32):
                    with cols[i%4]:
                        val = st.text_input(f"팀 {i+1}", value=f"팀 {i+1}")
                        team_names.append(val)
                
                submitted = st.form_submit_button("대진표 생성 및 시작 (수동)")
                if submitted:
                    db.set_teams(team_names)
                    teams_objs = db.get_teams()
                    groups = logic.generate_groups(teams_objs)
                    db.set_groups(groups)
                    matches = logic.generate_schedule(groups)
                    db.set_matches(matches)
                    logic.assign_matches_to_courts(db)
                    st.rerun()

        with tab_excel:
            st.info("엑셀 파일(.xlsx)을 업로드하세요. (형식: Team Name, Player 1, Player 2, Group(선택))")
            st.write("헤더 이름은 'Team', 'Player1', 'Player2', 'Group' 으로 맞춰주세요.")
            
            # Template Download
            import io
            buffer = io.BytesIO()
            sample_data = [
                {"Team": "Team A", "Player1": "홍길동", "Player2": "김철수", "Group": 1},
                {"Team": "Team B", "Player1": "이영희", "Player2": "박민수", "Group": 1},
                {"Team": "Team C", "Player1": "최지우", "Player2": "정우성", "Group": 2},
                # ...
            ]
            # Create 32 rows for convenience? or just sample.
            # Let's create an empty template with 32 rows of placeholders
            template_data = []
            for i in range(32):
                template_data.append({
                    "Team": f"Team {i+1}", 
                    "Player1": "", 
                    "Player2": "", 
                    "Group": (i // 4) + 1 # Default suggestion
                })
            
            df_template = pd.DataFrame(template_data)
            
            # Save to buffer
            with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
                df_template.to_excel(writer, index=False, sheet_name='참가신청서')
                
            st.download_button(
                label="📥 참가신청서 양식 다운로드 (Excel)",
                data=buffer.getvalue(),
                file_name="tournament_entry_template.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
            
            st.divider()
            
            uploaded_file = st.file_uploader("엑셀 파일 선택", type=['xlsx'])
            if uploaded_file:
                try:
                    df = pd.read_excel(uploaded_file)
                    # Helper to find cols case-insensitively
                    cols = {c.lower(): c for c in df.columns}
                    
                    # Target Cols
                    c_team = cols.get('team') or cols.get('team name') or cols.get('팀명') or cols.get('팀이름')
                    c_p1 = cols.get('player1') or cols.get('선수1')
                    c_p2 = cols.get('player2') or cols.get('선수2')
                    c_grp = cols.get('group') or cols.get('조') or cols.get('draw')
                    
                    if not c_team:
                        st.error("오류: 'Team' 또는 '팀명' 컬럼을 찾을 수 없습니다.")
                    else:
                        st.success(f"{len(df)}개의 팀을 발견했습니다.")
                        st.dataframe(df.head())
                        
                        if st.button("업로드 된 데이터로 대회 시작"):
                            # Prepare Data
                            teams_data = []
                            pre_defined_groups = {}
                            
                            for idx, row in df.iterrows():
                                if idx >= 32: break # Limit 32
                                
                                p1 = str(row[c_p1]) if c_p1 and pd.notna(row[c_p1]) else ""
                                p2 = str(row[c_p2]) if c_p2 and pd.notna(row[c_p2]) else ""
                                
                                # User Request: Team Name = "Player1, Player2"
                                if p1 and p2:
                                    t_name = f"{p1}, {p2}"
                                elif p1:
                                    t_name = p1
                                else:
                                    # Fallback to Team column or default
                                    t_name = str(row[c_team]) if c_team and pd.notna(row[c_team]) else f"Team {idx+1}"

                                t_data = {
                                    "name": t_name,
                                    "player1": p1,
                                    "player2": p2,
                                    "group": row[c_grp] if c_grp and pd.notna(row[c_grp]) else None
                                }
                                teams_data.append(t_data)
                                
                            # Fill rest if < 32? No, strict.
                            if len(teams_data) < 32:
                                st.warning("주의: 32팀보다 적습니다. 나머지는 더미로 채웁니다.")
                                for i in range(len(teams_data), 32):
                                    teams_data.append({"name": f"Team {i+1}", "player1": "", "player2": ""})
                                    
                            db.set_teams(teams_data)
                            teams_objs = db.get_teams()
                            
                            # Group Generation Logic
                            # If 'group' is in data, use it. 
                            # logic.generate_groups usually chunks list.
                            # We might need custom group assignment logic or sort teams by group first.
                            
                            has_groups = any(t.get('pre_group') for t in teams_objs)
                            
                            # Just call generate_groups. Logic handles both specific (if pre_group exists) and automatic assignment.
                            if not has_groups:
                                import random
                                random.shuffle(teams_objs)
                                db.teams = teams_objs
                                
                            groups = logic.generate_groups(teams_objs)
                            db.set_groups(groups)
                            matches = logic.generate_schedule(groups)
                            db.set_matches(matches)
                            logic.assign_matches_to_courts(db)
                            st.success("대회가 설정되었습니다!")
                            st.rerun()

                except Exception as e:
                    st.error(f"엑셀 처리 중 오류: {e}")
        return

    # Tournament Live View
    st.subheader(f"운영진 대시보드")
    
    # Check for active draw to highlight
    draw_active = db.knockout_draw.get('is_active', False)
    
    # Tabs
    tab_dash, tab_draw, tab_settings = st.tabs(["📊 대회 현황", "🎉 본선 조추첨", "⚙️ 설정 및 관리"])
    
    # --- TAB 1: DASHBOARD ---
    with tab_dash:
        col_actions = st.columns([4, 1])
        with col_actions[1]:
            if st.button("새로고침 (현황 업데이트)", type="primary", use_container_width=True):
                st.rerun()

        # 1. Live Courts
        st.subheader("실시간 코트 현황")
        courts = db.get_courts()
        matches = db.get_matches()
        
        c_cols = st.columns(3)
        for i in range(6):
            court = courts[i]
            match = next((m for m in matches if m['id'] == court['match_id']), None)
            
            with c_cols[i%3]:
                st.markdown(f"<h3 style='text-align: center; margin-bottom: 5px;'>{court['id']}번 코트</h3>", unsafe_allow_html=True)
                if match:
                    tA = next(t for t in teams if t['id'] == match['team_a_id'])
                    tB = next(t for t in teams if t['id'] == match['team_b_id'])
                    
                    nA = get_smart_name(tA).replace("\n", " ")
                    nB = get_smart_name(tB).replace("\n", " ")
                    
                    group_label = f"{match['group_id']}조" if isinstance(match['group_id'], int) else match['group_id']
                    
                    # Tie Break Logic
                    is_tie_break = match.get('is_tie_break', False)
                    pts_map = ['0', '15', '30', '40', 'AD']
                    
                    if is_tie_break:
                        pa = match['point_a']
                        pb = match['point_b']
                        tb_html = "<span style='background:#FF5722; color:white; font-size:0.6em; padding:2px 4px; border-radius:4px; vertical-align:middle;'>TIE BREAK</span>"
                    else:
                        pa = pts_map[match['point_a']]
                        pb = pts_map[match['point_b']]
                        tb_html = ""
                    
                    # Custom Card HTML
                    html = f"""
<div style="background-color: #262730; border: 1px solid #444; border-radius: 8px; padding: 15px; text-align: center; margin-bottom: 20px;">
<div style="color: #888; font-size: 0.9em; margin-bottom: 4px;">{group_label} {match['round']}경기 {tb_html}</div>
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
<div style="flex: 1; text-align: center;">
<div style="font-weight: bold; font-size: 1.1em; color: #fff;">{nA}</div>
</div>
<div style="font-weight: 900; font-size: 1.5em; padding: 0 10px; color: #ddd;">vs</div>
<div style="flex: 1; text-align: center;">
<div style="font-weight: bold; font-size: 1.1em; color: #fff;">{nB}</div>
</div>
</div>
<div style="background: #0e1117; border-radius: 6px; padding: 8px;">
<div style="font-size: 0.8em; color: #aaa;">SET SCORE</div>
<div style="font-size: 2.2em; font-weight: 900; color: #4CAF50;">{match['score_a']} : {match['score_b']}</div>
<div style="margin-top: 5px; font-size: 1.2em; color: #FFC107;">
<span style='font-size:0.7em; color:#777;'>POINTS</span> {pa} - {pb}
</div>
</div>
</div>
"""
                    st.markdown(html, unsafe_allow_html=True)
                else:
                    st.markdown("""
                     <div style="
                        background-color: #262730; 
                        border: 1px dotted #555; 
                        border-radius: 8px; 
                        padding: 30px; 
                        text-align: center; 
                        margin-bottom: 20px;
                        color: #666;
                     ">
                        대기 중
                     </div>
                     """, unsafe_allow_html=True)
                st.divider()
    
        # 2. Standings
        st.subheader("조별 순위")
        groups = db.get_groups()
        
        # Calculate stats
        team_stats = {t['id']: {'name': t['name'], 'W':0, 'L':0, 'D':0, 'Pts':0, 'Games':0} for t in teams}
        completed = [m for m in matches if m['status'] == 'COMPLETED']
        for m in completed:
             if m['is_draw']:
                 team_stats[m['team_a_id']]['D'] += 1
                 team_stats[m['team_a_id']]['Pts'] += 1
                 team_stats[m['team_b_id']]['D'] += 1
                 team_stats[m['team_b_id']]['Pts'] += 1
             elif m['winner_id']:
                 team_stats[m['winner_id']]['W'] += 1
                 team_stats[m['winner_id']]['Pts'] += 2
                 loser_id = m['team_b_id'] if m['winner_id'] == m['team_a_id'] else m['team_a_id']
                 team_stats[loser_id]['L'] += 1
                 team_stats[m['team_a_id']]['Games'] += m['score_a']
                 team_stats[m['team_b_id']]['Games'] += m['score_b']
        
        # Display Grid
        g_cols = st.columns(4)
        for i, group in enumerate(groups):
            with g_cols[i%4]:
                st.markdown(f"**{group['name']}**")
                data = []
                for tid in group['team_ids']:
                    s = team_stats[tid].copy()
                    # Helper to format name
                    def fmt_name(t):
                        base = t['name']
                        p1 = t.get('player1', '')
                        p2 = t.get('player2', '')
                        if p1 or p2:
                            if base == f"{p1}, {p2}" or (p1 and not p2 and base == p1): return base
                            if f"({p1}, {p2})" in base: return base
                            return f"{base} ({p1}, {p2})"
                        return base
                
                    t_obj = next((t for t in teams if t['id'] == tid), None)
                    if t_obj:
                        s['name'] = fmt_name(t_obj)
                    data.append(s)
                
                df = pd.DataFrame(data)
                df = df.sort_values(by=['Pts', 'Games'], ascending=[False, False])
                df = df.rename(columns={'name': '팀이름', 'W': '승', 'L': '패', 'D': '무', 'Pts': '승점', 'Games': '득실'})
                st.dataframe(df[['팀이름', '승', '무', '패', '승점', '득실']], hide_index=True, use_container_width=True)
    
        # 3. Schedule
        st.divider()
        bracket.render(db)
    
        # List view
        with st.expander("전체 경기 리스트"):
            st.subheader("전체 경기 일정")
            schedule_data = []
            for m in matches:
                tA = next(t for t in teams if t['id'] == m['team_a_id'])['name']
                tB = next(t for t in teams if t['id'] == m['team_b_id'])['name']
                status_map = {'PENDING': '대기', 'LIVE': '진행 중', 'COMPLETED': '종료'}
                schedule_data.append({
                    "상태": status_map[m['status']],
                    "경기": f"{m['group_id']}조 {m['round']}경기",
                    "대진": f"{tA} vs {tB}",
                    "점수": f"{m['score_a']} : {m['score_b']}"
                })
            st.dataframe(pd.DataFrame(schedule_data), hide_index=True, use_container_width=True)
    
    # --- TAB 2: DRAW ---
    with tab_draw:
        import random
        # Logic from draw.py
        state = db.knockout_draw
        current_round = state.get('current_round_name', '16강')
        st.header(f"🏆 {current_round} 조추첨")
        
        # Check if draw is active
        if not state['is_active']:
            history = state.get('round_history', [])
            if not history:
                # Check directly if matches are done
                if logic.check_preliminaries_complete(db):
                    st.info("예선 경기가 모두 종료되었습니다. 조추첨을 시작할 수 있습니다.")
                    if st.button("예선 결과 집계 및 조추첨 시작", type="primary"):
                        try:
                            logic.init_knockout_draw(db)
                            st.success("조추첨 준비 완료!")
                            st.rerun()
                        except Exception as e:
                            st.error(f"오류: {e}")
                else:
                    st.warning("⚠️ 아직 진행 중인 예선 경기가 있습니다. 모든 경기가 종료되어야 조추첨이 가능합니다.")
                    st.write("대회 현황 탭에서 남은 경기를 확인하세요.")
            else:
                last_round = history[-1]['name']
                if logic.check_round_complete(db, last_round):
                     st.success(f"{last_round} 경기가 모두 종료되었습니다.")
                     if st.button(f"다음 라운드 조추첨 시작", type="primary"):
                         logic.init_next_round_draw(db)
                         st.rerun()
                else:
                    st.warning(f"현재 {last_round} 경기가 진행 중입니다. 모든 경기가 종료되어야 다음 조추첨이 가능합니다.")
        else:
            # Draw Interface
            col_draw, col_result = st.columns([2, 1])
            with col_draw:
                st.subheader("추첨 진행")
                if state['current_drawer_idx'] >= len(state['pot_2']):
                    st.success("🎯 모든 조추첨이 완료되었습니다!")
                    st.markdown("---")
                    if st.button(f"🚀 {current_round} 토너먼트 시작하기", type="primary", use_container_width=True):
                        logic.start_knockout_round(db)
                        st.success(f"{current_round} 경기가 코트에 배정되었습니다!")
                        st.rerun()
                else:
                    current_drawer = state['pot_2'][state['current_drawer_idx']]
                    c_name = current_drawer['name']
                    p1 = current_drawer.get('player1', '')
                    p2 = current_drawer.get('player2', '')
                    if p1 or p2:
                         if f"{p1}, {p2}" not in c_name: c_name += f" ({p1}, {p2})"
                    
                    origin_label = current_drawer.get('group', '이전 라운드 승자')
                    st.info(f"👉 **{origin_label}** 에서 올라온 **'{c_name}'**의 추첨 차례입니다.")
                    st.write("아래 '물음표 카드' 중 하나를 선택하면 상대팀이 결정됩니다.")
                    
                    grid_cols = st.columns(4)
                    for i, target in enumerate(state['pot_1']):
                        with grid_cols[i % 4]:
                            if st.button(f"❓ 카드 {i+1}", key=f"card_{i}", use_container_width=True):
                                match_info = logic.perform_draw(db, i)
                                st.toast(f"추첨 결과: {match_info['home']['name']} vs {match_info['away']['name']}")
                                st.rerun()
            with col_result:
                st.subheader("대진표")
                if not state['matches']: st.info("아직 추첨된 대진이 없습니다.")
                for m in state['matches']:
                    t1 = m['home']
                    t2 = m['away']
                    st.warning(f"**{t1['name']}** vs **{t2['name']}**")
                    st.divider()

    # --- TAB 3: SETTINGS ---
    with tab_settings:
        st.subheader("⚙️ 설정 및 관리")
        
        # Export
        with st.expander("데이터 내보내기", expanded=True):
             if st.button("경기 결과 및 순위 엑셀(CSV) 저장"):
                 # (Use existing export logic helper needed? Just inline copy for now as it was local vars)
                 teams_export = db.get_teams()
                 stats = logic.calculate_standings(db)
                 export_data = []
                 for t in teams_export:
                     s = stats[t['id']]
                     export_data.append({
                         "ID": s['id'],
                         "팀이름": s['name'],
                         "승": s['W'], "무": s['D'], "패": s['L'], "승점": s['Pts'], "득실": s['Games']
                     })
                 df_standings = pd.DataFrame(export_data)
                 matches_export = db.get_matches()
                 match_data = []
                 for m in matches_export:
                      tA = next(t for t in teams_export if t['id'] == m['team_a_id'])
                      tB = next(t for t in teams_export if t['id'] == m['team_b_id'])
                      match_data.append({
                          "ID": m['id'], "구분": m['group_id'], "라운드": m['round'],
                          "홈팀": tA['name'], "원정팀": tB['name'], "스코어": f"{m['score_a']} : {m['score_b']}",
                          "승자": m['winner_id'] or "-", "상태": m['status']
                      })
                 df_matches = pd.DataFrame(match_data)
                 csv_standings = df_standings.to_csv(index=False).encode('utf-8-sig')
                 csv_matches = df_matches.to_csv(index=False).encode('utf-8-sig')
                 c1, c2 = st.columns(2)
                 c1.download_button("순위표 다운로드 (CSV)", csv_standings, "standings.csv", "text/csv")
                 c2.download_button("경기기록 다운로드 (CSV)", csv_matches, "matches.csv", "text/csv")
        
        # QR Code Generator
        with st.expander("🔗 QR 코드 생성 (모바일 접속용)", expanded=True):
            st.info("관람객 및 선수가 스마트폰으로 접속할 수 있는 통합 QR 코드를 생성합니다.")
            
            # Try to guess IP or let user input. 
            default_url = "http://192.168.4.201:8534" 
            base_url = st.text_input("현재 대회 서버 주소 (터미널의 Network URL을 입력하세요)", value=default_url)
            
            if base_url:
                # One QR for Home
                qr_api = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={base_url}"
                
                c_qr, c_desc = st.columns([1, 2])
                with c_qr:
                     st.image(qr_api, caption="대회 모바일 홈 접속 QR")
                with c_desc:
                     st.markdown("### 📱 모바일 접속 안내")
                     st.write("이 QR 코드를 촬영하면 **'대회 모바일 홈'**으로 접속됩니다.")
                     st.write("사용자는 홈 화면에서 **[관람용 대시보드]** 또는 **[선수 정보 조회]**를 선택할 수 있습니다.")
                     st.code(base_url)
            else:
                st.warning("서버 주소를 입력해야 QR 코드가 생성됩니다.")
        
        # Dev Tools
        with st.expander("개발자/테스트 도구"):
            if st.button("예선 전경기 랜덤 결과 생성 (바로 종료)", use_container_width=True):
                # (Same logic as before)
                import random
                for m in db.get_matches():
                    if m['status'] != 'COMPLETED':
                        m['score_a'] = random.randint(0, 6)
                        m['score_b'] = random.randint(0, 6)
                        if m['score_a'] == m['score_b']:
                             if m['score_a'] != 5: m['score_a'] = 6
                        
                        if m['score_a'] == 5 and m['score_b'] == 5:
                            m['is_draw'] = True; m['winner_id'] = None
                        elif m['score_a'] > m['score_b']:
                            m['winner_id'] = m['team_a_id']; m['score_a'] = 6
                        else:
                            m['winner_id'] = m['team_b_id']; m['score_b'] = 6
                        m['status'] = 'COMPLETED'; m['court_id'] = None
                for c in db.get_courts(): c['match_id'] = None
                st.success("완료")
                st.rerun()

        # Reset
        st.divider()
        st.warning("경고: 대회 초기화")
        if st.button("🧨 대회 완전 초기화 (Reset Tournament)", type="primary"):
             db.teams = []
             db.groups = []
             db.matches = []
             db.knockout_draw = {'is_active': False, 'pot_1': [], 'pot_2': [], 'matches': [], 'current_drawer_idx': 0, 'round_history': [], 'current_round_name': '16강'}
             for c in db.courts: c['match_id'] = None
             st.success("초기화되었습니다.")
             st.rerun()
